const express = require("express");
const Driver = require("../models/Driver");

const router = express.Router();

// Register Driver
router.post("/register", async(req,res)=>{
  const driver = new Driver(req.body);
  await driver.save();
  res.json({message:"Driver registered"});
});

// Get all drivers
router.get("/", async(req,res)=>{
  const drivers = await Driver.find();
  res.json(drivers);
});

// Approve Driver
router.put("/approve/:id", async(req,res)=>{
  await Driver.findByIdAndUpdate(req.params.id,{
    status:"approved"
  });
  res.json({message:"Driver approved"});
});

module.exports = router;