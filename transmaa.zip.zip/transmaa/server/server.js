const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

app.use("/bookings", require("./routes/bookingRoutes"));
app.use("/drivers",require("./routes/driverRoutes"));   

mongoose.connect("mongodb://127.0.0.1:27017/transmaa")
.then(()=>console.log("MongoDB connected"))
.catch(err=>console.log(err));

app.get("/", (req,res)=>{
    res.send("Backend running");
});

app.listen(5000, ()=>{
    console.log("Server started on port 5000");
});